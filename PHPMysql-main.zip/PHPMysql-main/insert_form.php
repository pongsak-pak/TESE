<html>
    <body>
    <form action = "insert.php" = method="post">
        ชื่อ:<input type="text" name="firstname" /> <br/>
        นามสกุล:<input type="text" name="lastname" /> <br/>
        email:<input type="hidden" value="m@mail.com" name="email" /> <br/>

        <input type="submit" value="บันทึก" name="submit_btn"/>
    </form>
    </body>
</html>